# Leadership OS - React Source Code

This package contains all the current React components for your Leadership OS frontend.

## 📦 What's Included

### Core Files
- **App.jsx** - Main application component with routing
- **main.jsx** - Entry point
- **index.css** - Global styles

### Components (src/components/)

1. **Sidebar.jsx** (2.9 KB)
   - Left navigation menu
   - Menu items: My Goals, Todo-list, My Team, My Journey, My Journal

2. **MyGoals.jsx** (12 KB)
   - Goal management with CRUD operations
   - ✨ Time horizon filters (Long/Medium/Short term)
   - Goal titles displayed prominently
   - Inline editing

3. **TodoList.jsx** (30 KB)
   - Task management with drag & drop
   - Filter sidebar (Due Date, Goals, Projects, Delegated)
   - ✨ Shows goal titles instead of full descriptions
   - Inline editing, priority management

4. **MyTeam.jsx** (12 KB)
   - Team member management
   - ✨ "Ask for Help" button that creates tasks
   - Contact information display
   - Inline editing

5. **MyLeadershipJourney.jsx** (26 KB)
   - Strengths, Development Areas, Projects, Failures, Opportunities
   - ✨ Fully editable entries (click to edit)
   - ✨ "+ Add" buttons for creating new items
   - Color-coded sections

6. **MyJournal.jsx** (6.5 KB)
   - Conversation history with Alfred
   - Filter by sender (All/You/Alfred)
   - Message statistics

### Old Versions (for reference)
- TodoList_OLD.jsx
- TodoList_old.jsx  
- TodoList_WITH_GOALS.jsx

## 🎨 Features Implemented

### Latest Updates (Current Build)
✅ Goal time horizon filters (Long/Medium/Short)
✅ Goal titles shown everywhere
✅ Journey page fully editable
✅ Journey "+ Add" buttons for all sections
✅ My Team "Ask for Help" creates tasks
✅ My Journal page with conversation history

## 🚀 How to Use These Files

### For Next Thread
Share these files so Claude can:
- See the current state of all components
- Make modifications while preserving existing functionality
- Understand the overall architecture

### To Deploy
These are the SOURCE files. To deploy:
1. Copy to your frontend/src directory
2. Run `npm run build`
3. Deploy the generated `static/` folder

## 📝 API Integration

All components connect to your FastAPI backend at:
- `https://greo-lead-production.up.railway.app`

User number: `whatsapp:+17707789240`

## 🔧 Dependencies

```json
{
  "react": "^18.2.0",
  "react-dom": "^18.2.0",
  "axios": "^1.6.2",
  "react-beautiful-dnd": "^13.1.1"
}
```

## 📊 Component Sizes

| Component | Lines | Features |
|-----------|-------|----------|
| TodoList.jsx | ~900 | Tasks, drag-drop, filters |
| MyLeadershipJourney.jsx | ~680 | Journey items, edit, add |
| MyGoals.jsx | ~370 | Goals with filters |
| MyTeam.jsx | ~310 | Team, ask for help |
| MyJournal.jsx | ~200 | Messages, filters |
| Sidebar.jsx | ~90 | Navigation |

## 🎯 Key Patterns Used

- **State Management**: React hooks (useState, useEffect)
- **API Calls**: Axios with async/await
- **Styling**: Tailwind CSS utility classes
- **Forms**: Controlled components
- **Drag & Drop**: react-beautiful-dnd

## 💡 Tips for Next Thread

When sharing with Claude:
1. Mention which component you want to modify
2. Describe the change you want
3. Claude can see the full current state and make precise updates

Example: "In MyGoals.jsx, I want to add a search bar above the filter buttons"

## 📱 Responsive Design

All components are mobile-responsive with:
- Desktop: Full sidebar, multi-column grids
- Mobile: Hamburger menu, single column

## 🔗 Component Dependencies

```
App.jsx
├── Sidebar.jsx
├── TodoList.jsx
├── MyGoals.jsx
├── MyTeam.jsx
├── MyLeadershipJourney.jsx
└── MyJournal.jsx
```

All components are independent and can be modified separately.
