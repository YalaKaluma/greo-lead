# Leadership OS - React Source Code (LATEST)

This package contains all the current React components for your Leadership OS frontend, including all the latest updates.

## 📦 What's Included

### Core Files
- **App.jsx** (3.7 KB) - Main application component with routing and URL param handling
- **main.jsx** - Entry point
- **index.css** - Global styles

### Components (src/components/)

1. **Sidebar.jsx** (2.9 KB)
   - Left navigation menu
   - Menu items: My Goals, Todo-list, My Team, My Journey, My Journal

2. **MyGoals.jsx** (21 KB) ⭐ UPDATED
   - Goal management with CRUD operations
   - ✨ Hierarchical goals (parent-child relationships)
   - ✨ Time horizon filters (Long/Medium/Short term) - NO EMOJIS
   - ✨ Clean goal cards (no date/time badges)
   - ✨ Icon-only buttons (📋 Tasks, 🗂️ Sub-Goals)
   - ✨ Tree structure view for goal hierarchy
   - Parent goal dropdown when creating/editing
   - Visual tree with connectors showing parent-child relationships

3. **TodoList.jsx** (30 KB)
   - Task management with drag & drop
   - Filter sidebar (Due Date, Goals, Projects, Delegated)
   - Shows goal titles instead of full descriptions
   - ✨ URL parameter filtering (by delegate or goal)
   - Inline editing, priority management

4. **MyTeam.jsx** (16 KB) ⭐ UPDATED
   - ✨ List layout (horizontal, one person per line)
   - ✨ Filter buttons (All / Team Members / Mentors / Peers)
   - ✨ "Ask for Help" button creates tasks
   - ✨ "📋 Tasks" link → filtered todo list
   - Contact information display
   - Inline editing

5. **MyLeadershipJourney.jsx** (26 KB)
   - Strengths, Development Areas, Projects, Failures, Opportunities
   - ✨ Fully editable entries (click to edit)
   - ✨ "+ Add" buttons for creating new items
   - Color-coded sections

6. **MyJournal.jsx** (6.5 KB)
   - Conversation history with Alfred
   - Filter by sender (All/You/Alfred)
   - Message statistics

### Old Versions (for reference)
- TodoList_OLD.jsx
- TodoList_old.jsx  
- TodoList_WITH_GOALS.jsx

## 🎨 Latest Features (This Build)

### MyGoals.jsx - Major Visual Update
✅ **Clean Filters**: No emojis on time horizon buttons
✅ **Minimal Cards**: Removed time badges and dates
✅ **Icon-Only Actions**: 📋 (Tasks) and 🗂️ (Hierarchy)
✅ **Tree View**: Visual hierarchy with parent at top, children indented with connectors
✅ **Parent-Child Goals**: Dropdown to select parent goal

### MyTeam.jsx - Complete Redesign
✅ **List Layout**: One horizontal line per person
✅ **Filters**: All / Team Members / Mentors / Peers
✅ **Task Links**: Click 📋 to see person's tasks
✅ **Ask for Help**: Creates delegated task

### TodoList.jsx - Smart Filtering
✅ **URL Parameters**: ?delegate=Jack or ?goal=5
✅ **Goal Titles**: Shows short titles, not full descriptions
✅ **Auto-filtering**: From MyTeam and MyGoals links

## 🗄️ Backend Requirements

### Database Schema Updates
MyGoals.jsx requires `parent_goal_id` column:

```sql
ALTER TABLE journey_goals ADD COLUMN parent_goal_id INTEGER;
ALTER TABLE journey_goals ADD CONSTRAINT fk_parent_goal 
  FOREIGN KEY (parent_goal_id) REFERENCES journey_goals(id) ON DELETE SET NULL;
CREATE INDEX idx_journey_goals_parent ON journey_goals(parent_goal_id);
```

### API Endpoints Used

**Journey Endpoints** (journey.py):
- GET/POST/PUT/DELETE `/api/journey/goals` - WITH parent_goal_id field
- GET/POST/PUT/DELETE `/api/journey/people`
- GET/POST/PUT/DELETE `/api/journey/strengths`
- GET/POST/PUT/DELETE `/api/journey/development-areas`
- GET/POST/PUT/DELETE `/api/journey/projects`
- GET/POST/PUT/DELETE `/api/journey/failures`
- GET/POST/PUT/DELETE `/api/journey/opportunities`

**Task Endpoints**:
- GET/POST/PUT/DELETE `/api/tasks/`
- GET `/api/tasks/filters`

**Message Endpoints**:
- GET `/api/messages/`

## 🚀 How to Use These Files

### For Next Thread
Upload this tarball and tell Claude:
- "Here are my current React components"
- Describe what you want to change
- Claude can see the full state and make precise updates

### To Deploy
1. Copy files to your frontend/src directory
2. Make sure backend has parent_goal_id column
3. Run `npm run build`
4. Deploy the generated `static/` folder

## 📝 Key Data Structures

### Goal Object (with parent_goal_id)
```javascript
{
  id: 1,
  title: "Complete MBA",
  goal_text: "Professional freedom...",
  why: "Build financial freedom",
  time_horizon: "long",
  parent_goal_id: null,  // NEW: ID of parent goal
  first_seen_at: "2025-12-07T...",
  updated_at: "2025-12-20T..."
}
```

### Sub-Goal Object
```javascript
{
  id: 5,
  title: "Pass GMAT",
  goal_text: "Pass GMAT exam",
  why: "Required for MBA",
  time_horizon: "short",
  parent_goal_id: 1,  // Links to parent goal
  first_seen_at: "2025-12-20T...",
  updated_at: "2025-12-20T..."
}
```

## 🎯 Component Interactions

### MyGoals → TodoList
```javascript
// Click Tasks icon (📋)
<a href={`/?page=todo-list&goal=${goal.id}`}>
  📋
</a>
// TodoList reads URL param and filters tasks
```

### MyTeam → TodoList
```javascript
// Click Tasks button
<a href={`/?page=todo-list&delegate=${person.name}`}>
  📋 Tasks
</a>
// TodoList reads URL param and filters by delegate
```

### MyGoals → Hierarchical View
```javascript
// Click hierarchy icon (🗂️)
<button onClick={() => setHierarchicalView(goal.id)}>
  🗂️
</button>
// Shows parent goal + children in tree structure
```

## 🔧 Dependencies

```json
{
  "react": "^18.2.0",
  "react-dom": "^18.2.0",
  "axios": "^1.6.2",
  "react-beautiful-dnd": "^13.1.1"
}
```

## 📊 Component Summary

| Component | Size | Key Features |
|-----------|------|--------------|
| MyGoals.jsx | 21 KB | Hierarchical goals, tree view, clean UI |
| TodoList.jsx | 30 KB | Tasks, drag-drop, URL filtering |
| MyLeadershipJourney.jsx | 26 KB | Journey items, CRUD, add forms |
| MyTeam.jsx | 16 KB | List view, filters, ask for help |
| MyJournal.jsx | 6.5 KB | Messages, filters |
| App.jsx | 3.7 KB | Routing, URL params |
| Sidebar.jsx | 2.9 KB | Navigation |

## 🎨 Visual Design Philosophy

**This Build:**
- ✨ Minimal icons (no text labels on actions)
- ✨ Clean cards (removed clutter like dates)
- ✨ No emojis in filters
- ✨ Tree structures for hierarchies
- ✨ Icon-only interactions (📋 🗂️)
- ✨ Right-aligned action icons

## 💡 For Your Next Session

When continuing work:
1. Upload this tarball
2. Mention specific component to modify
3. Describe desired changes
4. Claude has full context of current state

Example: "In MyGoals.jsx, I want to add a search bar to filter goals by title"

Perfect for maintaining continuity across sessions!
