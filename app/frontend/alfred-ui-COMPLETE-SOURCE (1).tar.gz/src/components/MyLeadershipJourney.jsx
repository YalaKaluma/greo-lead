import { useState, useEffect } from 'react';
import axios from 'axios';

export default function MyLeadershipJourney({ apiUrl, userNumber }) {
  const [data, setData] = useState({
    strengths: [],
    developmentAreas: [],
    projects: [],
    people: [],
    failures: [],
    opportunities: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const endpoints = [
        { key: 'strengths', url: `${apiUrl}/api/journey/strengths` },
        { key: 'developmentAreas', url: `${apiUrl}/api/journey/development-areas` },
        { key: 'projects', url: `${apiUrl}/api/journey/projects` },
        { key: 'people', url: `${apiUrl}/api/journey/people` },
        { key: 'failures', url: `${apiUrl}/api/journey/failures` },
        { key: 'opportunities', url: `${apiUrl}/api/journey/opportunities` }
      ];

      const results = await Promise.all(
        endpoints.map(async ({ key, url }) => {
          try {
            const response = await axios.get(url, {
              params: { user_number: userNumber }
            });
            // Backend returns array directly: [items]
            return { key, data: Array.isArray(response.data) ? response.data : [] };
          } catch (err) {
            console.error(`Error fetching ${key}:`, err);
            return { key, data: [] };
          }
        })
      );

      const newData = {};
      results.forEach(({ key, data }) => {
        newData[key] = data;
      });

      setData(newData);
    } catch (err) {
      console.error('Error fetching journey data:', err);
      setError('Failed to load journey data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-800">My Leadership Journey</h1>
        <p className="text-slate-600 mt-1">Your professional growth and development</p>
      </div>

      {/* 1. Strengths */}
      <Section title="Strengths" color="green" isEmpty={data.strengths.length === 0}>
        {data.strengths.length === 0 ? (
          <EmptyState message="No strengths captured yet" />
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {data.strengths.map((item) => (
              <Card key={item.id} color="green">
                <p className="text-slate-800 font-medium">{item.strength}</p>
                {item.source && (
                  <p className="text-sm text-slate-600 mt-2">
                    <span className="font-medium">Source:</span> {item.source}
                  </p>
                )}
              </Card>
            ))}
          </div>
        )}
      </Section>

      {/* 2. Development Areas */}
      <Section title="Development Areas" color="amber" isEmpty={data.developmentAreas.length === 0}>
        {data.developmentAreas.length === 0 ? (
          <EmptyState message="No development areas captured yet" />
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {data.developmentAreas.map((item) => (
              <Card key={item.id} color="amber">
                <p className="text-slate-800 font-medium">{item.skill}</p>
                {item.source && (
                  <p className="text-sm text-slate-600 mt-2">
                    <span className="font-medium">Source:</span> {item.source}
                  </p>
                )}
              </Card>
            ))}
          </div>
        )}
      </Section>

      {/* 3. Projects */}
      <Section title="Projects" color="blue" isEmpty={data.projects.length === 0}>
        {data.projects.length === 0 ? (
          <EmptyState message="No projects captured yet" />
        ) : (
          <div className="space-y-4">
            {data.projects.map((item) => (
              <Card key={item.id} color="blue">
                <h3 className="font-bold text-slate-800 mb-2">{item.project_name}</h3>
                {item.goal && (
                  <p className="text-sm text-slate-700 mb-2">
                    <span className="font-medium">Goal:</span> {item.goal}
                  </p>
                )}
                {item.description && (
                  <p className="text-sm text-slate-600 mb-2">{item.description}</p>
                )}
                {item.status && (
                  <span className="inline-block px-2 py-1 bg-blue-200 text-blue-800 rounded text-xs font-medium">
                    {item.status}
                  </span>
                )}
              </Card>
            ))}
          </div>
        )}
      </Section>

      {/* 4. Important People */}
      <Section title="Important People" color="purple" isEmpty={data.people.length === 0}>
        {data.people.length === 0 ? (
          <EmptyState message="No people captured yet" />
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {data.people.map((item) => (
              <Card key={item.id} color="purple">
                <h3 className="font-bold text-slate-800">{item.name}</h3>
                {item.relation && (
                  <p className="text-sm text-slate-600 mt-1">{item.relation}</p>
                )}
                <div className="mt-2 space-y-1">
                  {item.email && (
                    <p className="text-sm text-slate-600">📧 {item.email}</p>
                  )}
                  {item.phone && (
                    <p className="text-sm text-slate-600">📱 {item.phone}</p>
                  )}
                </div>
                {item.context && (
                  <p className="text-sm text-slate-600 mt-2 pt-2 border-t border-purple-200">
                    {item.context}
                  </p>
                )}
              </Card>
            ))}
          </div>
        )}
      </Section>

      {/* 5. Failures & Learnings */}
      <Section title="Failures & Learnings" color="red" isEmpty={data.failures.length === 0}>
        {data.failures.length === 0 ? (
          <EmptyState message="No failures captured yet" />
        ) : (
          <div className="space-y-4">
            {data.failures.map((item) => (
              <Card key={item.id} color="red">
                <p className="text-slate-800 mb-3">{item.failure_text}</p>
                {item.learning && (
                  <div className="bg-white rounded p-3 mb-2">
                    <p className="text-sm font-medium text-slate-700 mb-1">Learning:</p>
                    <p className="text-sm text-slate-600">{item.learning}</p>
                  </div>
                )}
                {item.scar && (
                  <div className="bg-white rounded p-3">
                    <p className="text-sm font-medium text-slate-700 mb-1">Scar:</p>
                    <p className="text-sm text-slate-600">{item.scar}</p>
                  </div>
                )}
              </Card>
            ))}
          </div>
        )}
      </Section>

      {/* 6. Opportunities */}
      <Section title="Opportunities" color="indigo" isEmpty={data.opportunities.length === 0}>
        {data.opportunities.length === 0 ? (
          <EmptyState message="No opportunities captured yet" />
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {data.opportunities.map((item) => (
              <Card key={item.id} color="indigo">
                <p className="text-slate-800 font-medium mb-2">{item.opportunity_text}</p>
                {item.category && (
                  <span className="inline-block px-2 py-1 bg-indigo-200 text-indigo-800 rounded text-xs font-medium">
                    {item.category}
                  </span>
                )}
              </Card>
            ))}
          </div>
        )}
      </Section>
    </div>
  );
}

// Section Component
function Section({ title, color, isEmpty, children }) {
  return (
    <div>
      <h2 className="text-2xl font-bold text-slate-800 mb-4">{title}</h2>
      {children}
    </div>
  );
}

// Card Component
function Card({ children, color }) {
  const colorClasses = {
    green: 'bg-green-50 border-green-200',
    amber: 'bg-amber-50 border-amber-200',
    blue: 'bg-blue-50 border-blue-200',
    purple: 'bg-purple-50 border-purple-200',
    red: 'bg-red-50 border-red-200',
    indigo: 'bg-indigo-50 border-indigo-200'
  };

  return (
    <div className={`${colorClasses[color]} border rounded-lg p-4`}>
      {children}
    </div>
  );
}

// Empty State Component
function EmptyState({ message }) {
  return (
    <div className="text-center py-8 text-slate-500">
      {message}
    </div>
  );
}
