import { useState, useEffect } from 'react';
import axios from 'axios';

export default function MyGoals({ apiUrl, userNumber }) {
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingGoalId, setEditingGoalId] = useState(null);

  useEffect(() => {
    fetchGoals();
  }, []);

  const fetchGoals = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(`${apiUrl}/api/journey/goals`, {
        params: { user_number: userNumber }
      });
      if (response.data && Array.isArray(response.data)) {
        // Sort: Long -> Medium -> Short
        const sorted = response.data.sort((a, b) => {
          const order = { long: 1, medium: 2, short: 3 };
          return (order[a.time_horizon] || 2) - (order[b.time_horizon] || 2);
        });
        setGoals(sorted);
      }
    } catch (err) {
      console.error('Error fetching goals:', err);
      if (err.response?.status === 404) {
        setError('Journey goals endpoint not implemented yet');
      } else {
        setError('Failed to load goals');
      }
    } finally {
      setLoading(false);
    }
  };

  const addGoal = async (goalData) => {
    try {
      await axios.post(
        `${apiUrl}/api/journey/goals`,
        goalData,
        { params: { user_number: userNumber } }
      );
      await fetchGoals();
      setShowAddForm(false);
    } catch (err) {
      console.error('Error adding goal:', err);
      alert('Failed to add goal');
    }
  };

  const updateGoal = async (goalId, updates) => {
    try {
      await axios.put(
        `${apiUrl}/api/journey/goals/${goalId}`,
        updates,
        { params: { user_number: userNumber } }
      );
      await fetchGoals();
      setEditingGoalId(null);
    } catch (err) {
      console.error('Error updating goal:', err);
      alert('Failed to update goal');
    }
  };

  const deleteGoal = async (goalId) => {
    if (!confirm('Delete this goal?')) return;
    
    try {
      await axios.delete(`${apiUrl}/api/journey/goals/${goalId}`, {
        params: { user_number: userNumber }
      });
      setGoals(goals.filter(g => g.id !== goalId));
    } catch (err) {
      console.error('Error deleting goal:', err);
      alert('Failed to delete goal');
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString('en-US', { 
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getTimeHorizonBadge = (horizon) => {
    const colors = {
      short: 'bg-blue-100 text-blue-800',
      medium: 'bg-purple-100 text-purple-800',
      long: 'bg-green-100 text-green-800'
    };
    return colors[horizon] || colors.medium;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">My Goals</h1>
          <p className="text-slate-600 mt-1">Your aspirations and objectives</p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
        >
          + Add Goal
        </button>
      </div>

      {/* Add Goal Form */}
      {showAddForm && (
        <GoalForm
          onSubmit={addGoal}
          onCancel={() => setShowAddForm(false)}
        />
      )}

      {/* Goals Grid */}
      {goals.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-slate-600 text-lg">
            No goals yet. Share your goals with Alfred or add them here!
          </p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {goals.map((goal) => (
            editingGoalId === goal.id ? (
              <GoalForm
                key={goal.id}
                goal={goal}
                onSubmit={(data) => updateGoal(goal.id, data)}
                onCancel={() => setEditingGoalId(null)}
                onDelete={() => deleteGoal(goal.id)}
              />
            ) : (
              <div
                key={goal.id}
                className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => setEditingGoalId(goal.id)}
              >
                <h3 className="text-lg font-semibold text-slate-800 mb-3">
                  {goal.goal_text}
                </h3>

                {goal.why && (
                  <div className="mb-3">
                    <span className="text-sm font-medium text-slate-600">Why: </span>
                    <span className="text-sm text-slate-600">{goal.why}</span>
                  </div>
                )}

                {goal.time_horizon && (
                  <div className="mb-3">
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getTimeHorizonBadge(goal.time_horizon)}`}>
                      {goal.time_horizon.charAt(0).toUpperCase() + goal.time_horizon.slice(1)} Term
                    </span>
                  </div>
                )}

                {goal.first_seen_at && (
                  <div className="text-xs text-slate-400 mt-4 pt-3 border-t border-gray-100">
                    Added {formatDate(goal.first_seen_at)}
                  </div>
                )}
              </div>
            )
          ))}
        </div>
      )}
    </div>
  );
}

// Goal Form Component
function GoalForm({ goal, onSubmit, onCancel, onDelete }) {
  const [formData, setFormData] = useState({
    goal_text: goal?.goal_text || '',
    why: goal?.why || '',
    time_horizon: goal?.time_horizon || 'medium'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.goal_text.trim()) {
      alert('Please enter a goal');
      return;
    }
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4 space-y-3">
      <h3 className="font-semibold text-slate-800">{goal ? 'Edit Goal' : 'Add New Goal'}</h3>
      
      <textarea
        value={formData.goal_text}
        onChange={(e) => setFormData({ ...formData, goal_text: e.target.value })}
        placeholder="What is your goal?"
        rows={3}
        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        required
      />

      <textarea
        value={formData.why}
        onChange={(e) => setFormData({ ...formData, why: e.target.value })}
        placeholder="Why is this important?"
        rows={2}
        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
      />

      <select
        value={formData.time_horizon}
        onChange={(e) => setFormData({ ...formData, time_horizon: e.target.value })}
        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        <option value="short">Short Term</option>
        <option value="medium">Medium Term</option>
        <option value="long">Long Term</option>
      </select>

      <div className="flex gap-2">
        <button
          type="submit"
          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded font-medium"
        >
          Save
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-2 rounded font-medium"
        >
          Cancel
        </button>
        {goal && onDelete && (
          <button
            type="button"
            onClick={onDelete}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded font-medium"
          >
            Delete
          </button>
        )}
      </div>
    </form>
  );
}
